from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from . import calc, schemas
from .auth import get_current_user, hash_password, make_token, verify_password
from .database import get_db
from .gemini_service import get_advice
from .models import AIAdvice, FinancialData, ScoreHistory, User

router = APIRouter()


@router.post("/register", response_model=schemas.TokenOut, status_code=201)
def register(b: schemas.RegisterIn, db: Session = Depends(get_db)):
    taken = HTTPException(409, "An account with this email already exists.")
    email = b.email.lower()
    if db.query(User).filter_by(email=email).first():
        raise taken
    user = User(name=b.name.strip(), email=email, hashed_password=hash_password(b.password))
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise taken
    return {"access_token": make_token(user.id)}


@router.post("/login", response_model=schemas.TokenOut)
def login(b: schemas.LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=b.email.lower()).first()
    if not user or not verify_password(b.password, user.hashed_password):
        raise HTTPException(401, "Incorrect email or password.")
    return {"access_token": make_token(user.id)}


def _fd(db, uid):
    return db.query(FinancialData).filter_by(user_id=uid).first()


def _last(db, uid):
    return (db.query(ScoreHistory).filter_by(user_id=uid)
            .order_by(ScoreHistory.recorded_at.desc(), ScoreHistory.id.desc()).first())


def _out(fd, db):
    last, a = _last(db, fd.user_id), []
    if fd.credit_utilization > 30:
        a.append(f"Credit utilisation is {fd.credit_utilization:.0f}%. Bring it under 30%.")
    if fd.dti_ratio > 40:
        a.append(f"Debt-to-income ratio is {fd.dti_ratio:.0f}%. Lenders prefer under 40%.")
    if fd.monthly_expenses >= fd.monthly_income:
        a.append("Monthly expenses are at or above income, so missed payments become likely.")
    if fd.credit_score < 700:
        a.append("Your score is below 700, the usual cut-off for the best loan rates.")
    row = {c.name: getattr(fd, c.name) for c in fd.__table__.columns}
    return {**row, "category": calc.category(fd.credit_score),
            "improvement_delta": last.improvement_delta if last else 0, "alerts": a}


def _save(db, user, body, fd):
    prev = _last(db, user.id)
    if fd is None:
        fd = FinancialData(user_id=user.id)
        db.add(fd)
    for k, v in body.model_dump().items():
        setattr(fd, k, v)
    fd.credit_utilization = calc.utilization(body.total_debt, body.credit_limit)
    fd.dti_ratio = calc.dti(body.monthly_debt_payment, body.monthly_income)
    db.add(ScoreHistory(user_id=user.id, credit_score=body.credit_score,
                        improvement_delta=calc.delta(prev.credit_score if prev else None, body.credit_score)))
    db.commit()
    db.refresh(fd)
    return _out(fd, db)


@router.post("/financial-data", response_model=schemas.FinancialOut, status_code=201)
def create_data(b: schemas.FinancialIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if _fd(db, user.id):
        raise HTTPException(409, "Financial data already exists. Use PUT to update it.")
    return _save(db, user, b, None)


@router.put("/financial-data", response_model=schemas.FinancialOut)
def update_data(b: schemas.FinancialIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    fd = _fd(db, user.id)
    if not fd:
        raise HTTPException(404, "No financial data yet. Use POST to create it.")
    return _save(db, user, b, fd)


@router.get("/financial-data", response_model=schemas.FinancialOut)
def get_data(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    fd = _fd(db, user.id)
    if not fd:
        raise HTTPException(404, "No financial data yet.")
    return _out(fd, db)


@router.get("/history", response_model=List[schemas.HistoryOut])
def history(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return (db.query(ScoreHistory).filter_by(user_id=user.id)
            .order_by(ScoreHistory.recorded_at, ScoreHistory.id).all())


@router.get("/utilization")
def utilization(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    fd = _fd(db, user.id)
    if not fd:
        raise HTTPException(404, "No financial data yet.")
    return {"used": fd.total_debt, "available": max(fd.credit_limit - fd.total_debt, 0),
            "utilization_pct": fd.credit_utilization}


@router.post("/ai-advice", response_model=schemas.AdviceOut)
def ai_advice(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    fd = _fd(db, user.id)
    if not fd:
        raise HTTPException(400, "Add your financial details before asking for advice.")
    keys = ("credit_score", "monthly_income", "monthly_expenses", "monthly_debt_payment",
            "total_debt", "credit_limit", "credit_utilization", "dti_ratio")
    r = get_advice({k: getattr(fd, k) for k in keys})
    row = AIAdvice(user_id=user.id, **r)
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/ai-advice/latest", response_model=schemas.AdviceOut)
def latest_advice(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    row = db.query(AIAdvice).filter_by(user_id=user.id).order_by(AIAdvice.id.desc()).first()
    if not row:
        raise HTTPException(404, "No advice yet.")
    return row
