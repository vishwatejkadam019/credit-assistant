import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api, { errMsg } from "../api";

function AuthForm({ mode }) {
  const reg = mode === "register";
  const nav = useNavigate();
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setErr(""); setBusy(true);
    try {
      const { data } = await api.post(reg ? "/register" : "/login", reg ? f : { email: f.email, password: f.password });
      localStorage.setItem("token", data.access_token);
      nav(reg ? "/data" : "/");
    } catch (x) { setErr(errMsg(x)); } finally { setBusy(false); }
  };

  return (
    <div className="auth">
      <form className="card" onSubmit={submit}>
        <h1>{reg ? "Create your account" : "Log in"}</h1>
        {reg && <label>Name<input required minLength={2} value={f.name} onChange={set("name")} /></label>}
        <label>Email<input required type="email" value={f.email} onChange={set("email")} /></label>
        <label>Password<input required type="password" minLength={reg ? 8 : 1} value={f.password} onChange={set("password")} /></label>
        {reg && <small className="muted">At least 8 characters.</small>}
        {err && <p className="error" role="alert">{err}</p>}
        <button className="btn" disabled={busy}>{busy ? "Please wait…" : reg ? "Create account" : "Log in"}</button>
        <p className="muted">{reg ? <>Have an account? <Link to="/login">Log in</Link></> : <>New here? <Link to="/register">Create an account</Link></>}</p>
      </form>
    </div>
  );
}
export const Login = () => <AuthForm mode="login" />;
export const Register = () => <AuthForm mode="register" />;
