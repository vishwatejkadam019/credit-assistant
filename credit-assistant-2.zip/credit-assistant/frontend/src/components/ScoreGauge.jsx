// A 300-900 score band with a marker, so the score is read in context.
const SEG = [["Poor", 300, 600, "#B3261E"], ["Fair", 600, 700, "#D98E04"], ["Good", 700, 750, "#4E8F3A"], ["Excellent", 750, 900, "#0F7C86"]];
const TICKS = [300, 600, 700, 750, 900];
const at = (v) => `${(v - 300) / 6}%`;

export default function ScoreGauge({ score, category, delta }) {
  return (
    <div className="gauge">
      <div className="score">
        <span className="num">{score}</span>
        <span className={`badge ${category}`}>{category}</span>
        <span className={delta > 0 ? "up" : delta < 0 ? "down" : "muted"}>
          {delta > 0 ? "▲ " : delta < 0 ? "▼ " : ""}{delta === 0 ? "No change" : `${Math.abs(delta)} points`} since last update
        </span>
      </div>
      <div className="bar" role="img" aria-label={`Score ${score} of 900, ${category}`}>
        {SEG.map(([n, a, b, c]) => <i key={n} style={{ width: at(b - a + 300), background: c }} />)}
        <b className="marker" style={{ left: at(score) }} />
      </div>
      <div className="ticks">{TICKS.map((t) => <span key={t} style={{ left: at(t) }}>{t}</span>)}</div>
    </div>
  );
}
