import { Navigate, NavLink, Outlet, Route, Routes, useNavigate } from "react-router-dom";
import { Login, Register } from "./pages/Auth.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import DataForm from "./pages/DataForm.jsx";
import Advisor from "./pages/Advisor.jsx";

function Shell() {
  const nav = useNavigate();
  if (!localStorage.getItem("token")) return <Navigate to="/login" replace />;
  const logout = () => { localStorage.removeItem("token"); nav("/login"); };
  return (
    <div className="app">
      <header>
        <b className="brand">Credit Assistant</b>
        <nav>
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/data">Update details</NavLink>
          <NavLink to="/advisor">AI advisor</NavLink>
        </nav>
        <button className="ghost" onClick={logout}>Log out</button>
      </header>
      <main><Outlet /></main>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route element={<Shell />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/data" element={<DataForm />} />
        <Route path="/advisor" element={<Advisor />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
