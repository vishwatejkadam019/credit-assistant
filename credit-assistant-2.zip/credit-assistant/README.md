# Credit Assistant: AI-Powered Financial Health Advisor

FastAPI + SQLAlchemy backend, Gemini advice, React (Vite) dashboard for Indian credit health (CIBIL 300-900).

```
credit-assistant/
├── backend/   app/{main,routes,models,schemas,auth,calc,gemini_service,database}.py, seed.py, tests/
└── frontend/  src/{App.jsx,api.js,pages/,components/}
```

## Run locally
```bash
# Backend (Python 3.9+)
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # set JWT_SECRET and GEMINI_API_KEY
python seed.py              # optional: demo@creditassistant.in / Demo@1234
uvicorn app.main:app --reload     # docs at http://localhost:8000/docs
pytest                      # DTI, utilisation, category, delta tests

# Frontend
cd ../frontend && cp .env.example .env && npm install && npm run dev   # http://localhost:5173
```

## API (JWT bearer on everything except /register and /login)
| Method | Path | Purpose |
|---|---|---|
| POST | /register, /login | Returns `access_token` |
| POST / PUT / GET | /financial-data | Create / update / read. Computes DTI and utilisation, appends a score_history row with delta |
| GET | /history | Score timeline (line chart) |
| GET | /utilization | used / available / % (pie chart) |
| POST | /ai-advice | Gemini analysis + 5-step plan, stored |
| GET | /ai-advice/latest | Last stored advice |

## Deploy on AWS
**Backend (EC2):** launch Ubuntu t3.small, open ports 22 and 80/443, install Python and nginx, clone the repo, create a venv, `pip install -r requirements.txt`, set env vars (`DATABASE_URL` pointing to RDS PostgreSQL, `JWT_SECRET`, `GEMINI_API_KEY`, `CORS_ORIGINS=https://your-cloudfront-domain`; add `psycopg2-binary`), run `uvicorn app.main:app --host 127.0.0.1 --port 8000` under systemd, and proxy nginx to it with a Let's Encrypt certificate.
**Frontend (S3 + CloudFront):** set `VITE_API_URL` to your API URL, `npm run build`, create a private S3 bucket, `aws s3 sync dist/ s3://BUCKET --delete`, create a CloudFront distribution with origin access control, default root `index.html`, and custom error responses 403/404 -> `/index.html` (200) for React Router.
Elastic Beanstalk also works for the backend (Python platform, `Procfile`: `web: uvicorn app.main:app --host 0.0.0.0 --port 8000`).

## Assumptions
- Added `monthly_debt_payment` to `financial_data` (DTI needs it) and `category`/`source` to `ai_advice`.
- Score bands: Poor <600, Fair 600-699, Good 700-749, Excellent 750+. Alerts: utilisation >30%, DTI >40%.
- If `GEMINI_API_KEY` is missing or Gemini fails, rule-based advice is returned (`source: "fallback"`).
- Set `GEMINI_MODEL` if Google retires the default model name.

## Final checklist
1. **Onboarding:** register -> details form -> save. Dashboard shows DTI and utilisation; `GET /financial-data` has `dti_ratio`.
2. **AI consultation:** log in as demo (688, Fair) -> "Get AI advice". Analysis and 5 steps appear and `ai_advice` has a new row.
3. **Progress:** demo dashboard line chart shows 7 points rising 596 -> 688.
4. **Real-time:** Update details (e.g. lower total debt, raise score). Dashboard shows a new delta, a new chart point, and a smaller "Debt used" pie slice.
5. Invalid score (e.g. 950) is rejected; calling an endpoint without a token returns 401; `pytest` passes.
